x = range(10)
print(x)
print(list(x))

x =range(-9)
print(list(x))
print(list(range(5, 10)))
print(list(range(10, 100, 20)))
