instrumentos = { 'piano', 'guitarra', 'violin', 'bateria'}
print(instrumentos)
print(set('abracadabra'))
print(set('abracadabra'))
#Crearemos un conjunto vacio
x = set()
#Utilizaremos el metodo de add para agregar valores
x.add(3)
x.add(9)
x.add(81)
print(x)

x.discard(3)
print(x)
