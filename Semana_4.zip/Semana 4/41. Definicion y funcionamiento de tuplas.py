tupla = 'Esta es una tupla diversa', [1, 2, 3, 4, 5, 6], 'a', 4.56
print(tupla[0])
print(tupla[1])
saludo, lista, letra, decimal = tupla
print("Saludo: ", saludo)
print("Lista: ", lista)
print("Letra: ", letra)
print("Decimal: ", decimal)
